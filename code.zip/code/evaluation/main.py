import csv
from pathlib import Path


ROOT = Path(__file__).resolve().parent.parent
DATASET = ROOT / "dataset"


def load_csv(filename):
    path = DATASET / filename

    with open(path, "r", encoding="utf-8-sig", newline="") as file:
        return list(csv.DictReader(file))


def main():
    requests = load_csv("requests.csv")
    samples = load_csv("sample_requests.csv")
    profiles = load_csv("financial_profiles.csv")
    events = load_csv("financial_events.csv")
    payment_options = load_csv("request_payment_options.csv")
    messages = load_csv("messages.csv")
    images = load_csv("images.csv")
    exchange_rates = load_csv("exchange_rates.csv")

    print("Dataset loaded successfully!")
    print()

    print("requests:", len(requests))
    print("samples:", len(samples))
    print("profiles:", len(profiles))
    print("events:", len(events))
    print("payment options:", len(payment_options))
    print("messages:", len(messages))
    print("images:", len(images))
    print("exchange rates:", len(exchange_rates))


if __name__ == "__main__":
    main()