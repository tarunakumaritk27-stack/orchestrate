# Token Usage And Cost Analysis

Final run: deterministic local Python financial decision engine.

## Model providers
- Provider: None
- Model: None
- LLM/API calls: 0

## Token usage
- Input tokens: 0
- Output tokens: 0
- Total tokens: 0
- Average tokens per request: 0

## Estimated cost
- Total model/API cost: $0
- Average cost per request: $0

The final `output.csv` was produced by `code/main.py` without external model or API calls, so there are no model tokens or API charges to report.
