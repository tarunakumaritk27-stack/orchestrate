import csv
from pathlib import Path
from datetime import date, timedelta
from collections import defaultdict
from statistics import median


# ============================================================
# PATHS
# ============================================================

ROOT = Path(__file__).resolve().parent.parent
DATASET = ROOT / "dataset"
OUTPUT_FILE = ROOT / "output.csv"


# ============================================================
# OUTPUT SCHEMA
# ============================================================

OUTPUT_COLUMNS = [
    "request_id",
    "amount_safe_to_pay",
    "affordability_status",
    "recommended_payment_method",
    "payment_plan",
    "earliest_date_for_full_payment",
    "spending_changes_needed",
    "decision_explanation",
]


# ============================================================
# BASIC HELPERS
# ============================================================

def load_csv(filename):
    path = DATASET / filename

    with open(path, "r", encoding="utf-8-sig", newline="") as f:
        return list(csv.DictReader(f))


def parse_date(value):
    if not value:
        return None

    value = str(value).strip()

    if not value:
        return None

    return date.fromisoformat(value)


def money(value):
    if value is None:
        return 0.0

    text = str(value).strip()

    if text == "":
        return 0.0

    return float(text)


def bool_value(value):
    return str(value).strip().lower() in {
        "true",
        "1",
        "yes",
        "y",
    }


def split_values(value):
    if not value:
        return []

    text = str(value).replace(";", ",")

    return [
        x.strip().lower()
        for x in text.split(",")
        if x.strip()
    ]


def add_days(d, days):
    return d + timedelta(days=days)


def format_money(value):
    value = round(float(value), 2)

    if abs(value - round(value)) < 0.000001:
        return str(int(round(value)))

    return f"{value:.2f}"


# ============================================================
# LOAD DATA
# ============================================================

print("Loading datasets...")

requests = load_csv("requests.csv")
profiles = load_csv("financial_profiles.csv")
events = load_csv("financial_events.csv")
payment_options = load_csv("request_payment_options.csv")
exchange_rates_rows = load_csv("exchange_rates.csv")
messages = load_csv("messages.csv")
images = load_csv("images.csv")

print(f"Requests: {len(requests)}")
print(f"Profiles: {len(profiles)}")
print(f"Events: {len(events)}")
print(f"Payment options: {len(payment_options)}")


# ============================================================
# INDEXES
# ============================================================

profiles_by_user = {
    row["user_id"]: row
    for row in profiles
}


events_by_user = defaultdict(list)

for event in events:
    events_by_user[event["user_id"]].append(event)


options_by_request = defaultdict(list)

for option in payment_options:
    options_by_request[option["request_id"]].append(option)


messages_by_request = defaultdict(list)
messages_by_event = defaultdict(list)

for msg in messages:
    request_id = msg.get("request_id", "").strip()
    event_id = msg.get("related_event_id", "").strip()

    if request_id:
        messages_by_request[request_id].append(msg)

    if event_id:
        messages_by_event[event_id].append(msg)

messages_by_user = defaultdict(list)
for msg in messages:
    uid = msg.get("user_id", "").strip()
    if uid:
        messages_by_user[uid].append(msg)



images_by_request = defaultdict(list)
images_by_event = defaultdict(list)

for img in images:
    request_id = img.get("request_id", "").strip()
    event_id = img.get("related_event_id", "").strip()

    if request_id:
        images_by_request[request_id].append(img)

    if event_id:
        images_by_event[event_id].append(img)


# ============================================================
# EXCHANGE RATES
# ============================================================

exchange_rates = {}

for row in exchange_rates_rows:
    rate_date = row["rate_date"]
    from_currency = row["from_currency"].upper()
    to_currency = row["to_currency"].upper()

    exchange_rates[
        (rate_date, from_currency, to_currency)
    ] = money(row["rate"])


def convert_amount(
    amount,
    conversion_date,
    from_currency,
    to_currency,
):
    amount = float(amount)

    from_currency = str(from_currency).upper()
    to_currency = str(to_currency).upper()

    if from_currency == to_currency:
        return amount

    date_key = conversion_date.isoformat()

    direct = exchange_rates.get(
        (date_key, from_currency, to_currency)
    )

    if direct is not None:
        return amount * direct

    reverse = exchange_rates.get(
        (date_key, to_currency, from_currency)
    )

    if reverse is not None and reverse != 0:
        return amount / reverse

    raise ValueError(
        f"Missing exchange rate: "
        f"{date_key} {from_currency}->{to_currency}"
    )


# ============================================================
# AMOUNT RESOLUTION FOR EVENTS WITH MISSING AMOUNTS
# ============================================================

_image_amount_cache = {}


def resolve_event_amount(event):
    """Resolve a supplied event amount. Missing amounts are read from a linked image when possible."""
    raw=str(event.get("amount", "")).strip()
    if raw:
        return money(raw)
    event_id=event.get("event_id", "").strip()
    if not event_id:
        return None
    if event_id in _image_amount_cache:
        return _image_amount_cache[event_id]
    linked=images_by_event.get(event_id, [])
    if not linked:
        _image_amount_cache[event_id]=None
        return None
    # Optional OCR: no API/network and no secret. If tesseract is unavailable,
    # leave the value unresolved instead of treating it as zero.
    try:
        import shutil, subprocess, re
        exe=shutil.which("tesseract")
        if not exe:
            _image_amount_cache[event_id]=None
            return None
        image_id=linked[0].get("image_id", "")
        image_path=DATASET/"media"/"images"/(image_id+".png")
        if not image_path.exists():
            _image_amount_cache[event_id]=None; return None
        proc=subprocess.run([exe,str(image_path),"stdout","--psm","11"],capture_output=True,text=True,timeout=4)
        text=proc.stdout or ""
        lines=text.splitlines()
        candidates=[]
        for line in lines:
            low=line.lower()
            if not any(k in low for k in ("total","amount due","amount received","net pay","grand total","outstanding","balance","cash paid")):
                continue
            nums=re.findall(r'(?<!\d)(?:\d{1,3}(?:,\d{2,3})+|\d+(?:\.\d{1,2})?)(?!\d)',line)
            for n in nums:
                try:
                    v=float(n.replace(',',''))
                    if v>0: candidates.append((low,v))
                except: pass
        if not candidates:
            _image_amount_cache[event_id]=None; return None
        desc=event.get("description","").lower()
        # Context-sensitive selection without embedding dataset amounts.
        if "rent" in desc:
            preferred=[v for line,v in candidates if "amount received" in line or "balance" in line]
            value=preferred[-1] if preferred else candidates[-1][1]
        elif "telecom" in desc or "bill" in desc:
            preferred=[v for line,v in candidates if "amount due" in line or "total" in line]
            value=preferred[-1] if preferred else candidates[-1][1]
        else:
            value=candidates[-1][1]
        _image_amount_cache[event_id]=value
        return value
    except Exception:
        _image_amount_cache[event_id]=None
        return None


# ============================================================
# EVENT FILTERING
# ============================================================

IGNORED_STATUSES = {
    "failed",
    "cancelled",
    "unrealized",
}


def usable_event(event):
    status = str(event.get("status", "")).strip().lower()

    if status in IGNORED_STATUSES:
        return False

    direction = str(
        event.get("direction", "")
    ).strip().lower()

    if direction == "non_cash":
        return False

    return True


def event_date_for_forecast(event):
    settlement = parse_date(event.get("settlement_date"))

    event_date = parse_date(event.get("event_date"))

    status = str(
        event.get("status", "")
    ).strip().lower()

    # Settled transactions use their settlement date.
    if status == "settled" and settlement:
        return settlement

    # Future scheduled payments use settlement date if supplied.
    if status == "scheduled" and settlement:
        return settlement

    # Do not count pending credits.
    if status == "pending":
        direction = str(
            event.get("direction", "")
        ).strip().lower()

        if direction == "credit":
            return None

        # Pending debit is reserved, so use the event date
        # when available.
        if event_date:
            return event_date

    return settlement or event_date


# ============================================================
# RECURRING EXPENSE DETECTION
# ============================================================

def find_recurring_patterns(user_events, home_currency, cutoff_date=None):
    """Detect recurring settled debit patterns from history before cutoff_date."""
    grouped = defaultdict(list)
    for event in user_events:
        if not usable_event(event):
            continue
        if str(event.get("status", "")).strip().lower() != "settled":
            continue
        if str(event.get("direction", "")).strip().lower() != "debit":
            continue
        event_date = parse_date(event.get("event_date"))
        if not event_date or (cutoff_date and event_date >= cutoff_date):
            continue
        category = event.get("category", "").strip().lower()
        description = event.get("description", "").strip().lower()
        grouped[(category, description)].append(event)

    patterns = []
    for key, rows in grouped.items():
        rows = sorted(rows, key=lambda x: parse_date(x["event_date"]))
        recent_cutoff = parse_date(rows[-1]["event_date"]) - timedelta(days=180)
        rows = [r for r in rows if parse_date(r["event_date"]) >= recent_cutoff]
        if len(rows) < 3:
            continue
        dates = [parse_date(r["event_date"]) for r in rows]
        gaps = [(dates[i] - dates[i-1]).days for i in range(1, len(dates))]
        if not gaps:
            continue
        typical_gap = median(gaps)
        if not (5 <= typical_gap <= 9 or 12 <= typical_gap <= 16 or 25 <= typical_gap <= 35 or 85 <= typical_gap <= 95):
            continue
        amounts = []
        for r in rows:
            try:
                resolved=resolve_event_amount(r)
                if resolved is None: continue
                amounts.append(convert_amount(resolved, parse_date(r["event_date"]), r["currency"], home_currency))
            except Exception:
                pass
        if not amounts:
            continue
        if 5 <= typical_gap <= 9: frequency_days = 7
        elif 12 <= typical_gap <= 16: frequency_days = 14
        elif 25 <= typical_gap <= 35: frequency_days = 30
        else: frequency_days = 90
        latest_date = dates[-1]
        patterns.append({"category": key[0], "description": key[1], "amount": median(amounts),
                         "frequency_days": frequency_days, "next_date": latest_date + timedelta(days=frequency_days),
                         "event": rows[-1]})
    return patterns


def add_months_same_day(d, months=1):
    y=d.year + (d.month - 1 + months)//12
    m=(d.month - 1 + months)%12 + 1
    import calendar
    return date(y,m,min(d.day,calendar.monthrange(y,m)[1]))


def find_recurring_income(user_events, home_currency, cutoff_date):
    """Find regular monthly salary history before the request date."""
    rows=[]
    for event in user_events:
        if not usable_event(event): continue
        if str(event.get("status","")).strip().lower()!="settled": continue
        if str(event.get("direction","")).strip().lower()!="credit": continue
        if str(event.get("category","")).strip().lower() not in {"salary","income"}: continue
        d=parse_date(event.get("event_date"))
        if d and d<cutoff_date and ("salary" in event.get("description","").lower() or "payroll" in event.get("description","").lower() or "base salary" in event.get("description","").lower()): rows.append(event)
    if len(rows)<2: return []
    rows.sort(key=lambda x:parse_date(x["event_date"]))
    dates=[parse_date(r["event_date"]) for r in rows]
    gaps=[(dates[i]-dates[i-1]).days for i in range(1,len(dates))]
    if not gaps or not (25<=median(gaps)<=35): return []
    latest=rows[-1]
    try:
        resolved=resolve_event_amount(latest)
        if resolved is None: return []
        amt=convert_amount(resolved,dates[-1],latest["currency"],home_currency)
    except: return []
    return [{"amount":amt,"frequency_days":30,"next_date":add_months_same_day(dates[-1],1),"event":latest}]


def extract_message_income(user_id, start_date, home_currency):
    import re
    found=[]
    for msg in messages_by_user.get(user_id, []):
        text=str(msg.get("message_text", ""))
        sent=parse_date(str(msg.get("sent_at", ""))[:10])
        if sent and sent>start_date: continue
        # Explicit salary/pay amount. The message is treated only as evidence.
        pat=r'(?i)(?:salary|gaji|pay|monthly pay|confirmed salary|gaji pokok|gaji bulanan)[^\d]{0,100}([0-9][0-9,\.]{2,})\s*(IDR|INR|ZAR|USD|EUR)?'
        ms=list(re.finditer(pat,text))
        for mm in ms:
            try: amount=float(mm.group(1).replace(',',''))
            except: continue
            cur=(mm.group(2) or home_currency).upper()
            dates=re.findall(r'\b(20\d{2}-\d{2}-\d{2})\b',text)
            d=parse_date(dates[-1]) if dates else None
            if not d:
                # Infer the next payroll date from the user's latest historical salary day.
                sal=[]
                for e in events_by_user.get(user_id,[]):
                    if usable_event(e) and e.get("direction","").lower()=="credit" and e.get("category","").lower()=="salary":
                        ed=parse_date(e.get("event_date"));
                        if ed and ed<=start_date: sal.append(ed)
                if sal:
                    last=max(sal); d=add_months_same_day(last,1)
                else: d=start_date+timedelta(days=30)
            if d and d>start_date:
                try: amount=convert_amount(amount,d,cur,home_currency)
                except: pass
                found.append((d,amount))
    # Last message wins for the same date.
    out={d:a for d,a in found}
    return sorted(out.items())


def build_forecast(user_events, profile, start_date, home_currency, days=91):
    """Forecast from the current available balance; settled history after the request date is not future cash flow."""
    starting_balance=money(profile["current_available_balance"])
    balances={}
    daily_changes=defaultdict(float)
    forecast_end=start_date+timedelta(days=days-1)

    # Only future cash flows affect a balance that is already stated at request_date.
    for event in user_events:
        if not usable_event(event):
            continue
        status=str(event.get("status","")).strip().lower()
        d=event_date_for_forecast(event)
        if not d or d <= start_date or d > forecast_end:
            continue
        # A settled record after request_date is historical/leaked data, not a future commitment.
        if status == "settled":
            continue
        direction=str(event.get("direction","")).strip().lower()
        if direction not in {"debit","credit"}: continue
        try:
            resolved=resolve_event_amount(event)
            if resolved is None: continue
            converted=convert_amount(resolved,d,event["currency"],home_currency)
        except Exception: continue
        daily_changes[d] += converted if direction=="credit" else -converted

    # Recurring expenses are inferred strictly from settled history before request_date.
    recurring_patterns=find_recurring_patterns(user_events,home_currency,start_date)
    for pattern in recurring_patterns:
        d=pattern["next_date"]
        while d <= forecast_end:
            if d > start_date:
                # Do not duplicate a real future scheduled/pending debit.
                duplicate=False
                for event in user_events:
                    if not usable_event(event): continue
                    ed=event_date_for_forecast(event)
                    if ed != d: continue
                    if str(event.get("direction","")).strip().lower()!="debit": continue
                    if str(event.get("status","")).strip().lower()=="settled": continue
                    if event.get("category","").strip().lower()==pattern["category"] and event.get("description","").strip().lower()==pattern["description"]:
                        duplicate=True; break
                if not duplicate: daily_changes[d]-=pattern["amount"]
            d += timedelta(days=pattern["frequency_days"])

    # Regular salary recurrence from historical settled payroll.
    for inc in find_recurring_income(user_events,home_currency,start_date):
        d=inc["next_date"]
        while d<=forecast_end:
            if d>start_date: daily_changes[d]+=inc["amount"]
            d += timedelta(days=inc["frequency_days"])

    # Explicit message amendments/confirmed salary changes override/add to forecast.
    for d,amount in extract_message_income(profile["user_id"],start_date,home_currency):
        if d<=forecast_end: daily_changes[d]+=amount

    balance=starting_balance
    for i in range(days):
        d=start_date+timedelta(days=i)
        balance+=daily_changes[d]
        balances[d]=balance
    return balances, recurring_patterns


# ============================================================
# SAFETY CHECK
# ============================================================

def is_safe_forecast(
    forecast,
    minimum_balance,
    extra_payments=None,
):
    """
    extra_payments:
        dict[date] = amount to subtract

    Every day must remain >= minimum_balance.
    """

    extra_payments = extra_payments or {}

    for current_date, balance in forecast.items():

        adjusted_balance = (
            balance
            - extra_payments.get(current_date, 0.0)
        )

        if adjusted_balance < minimum_balance - 0.01:
            return False

    return True


# ============================================================
# SAFE AMOUNT TODAY
# ============================================================

def calculate_safe_amount(
    forecast,
    requested_amount,
    minimum_balance,
    request_date,
):
    """
    Maximum amount that can be paid today without optional
    spending changes.
    """

    if requested_amount <= 0:
        return 0.0

    available_today = (
        forecast.get(request_date, 0.0)
        - minimum_balance
    )

    if available_today <= 0:
        return 0.0

    upper = min(
        requested_amount,
        available_today,
    )

    low = 0.0
    high = upper

    for _ in range(60):

        mid = (low + high) / 2.0

        safe = is_safe_forecast(
            forecast,
            minimum_balance,
            {request_date: mid},
        )

        if safe:
            low = mid
        else:
            high = mid

    return min(
        requested_amount,
        max(0.0, round(low, 2)),
    )


# ============================================================
# EARLIEST FULL PAYMENT DATE
# ============================================================

def find_earliest_full_payment_date(
    forecast,
    requested_amount,
    minimum_balance,
    request_date,
):
    """
    Find the first forecast date where the complete amount
    can be paid as one payment.
    """

    if requested_amount <= 0:
        return request_date

    for current_date in sorted(forecast.keys()):

        extra = {
            current_date: requested_amount
        }

        if is_safe_forecast(
            forecast,
            minimum_balance,
            extra,
        ):
            return current_date

    return None


# ============================================================
# PAYMENT OPTIONS
# ============================================================

def get_request_payment_options(request_id):
    return options_by_request.get(
        request_id,
        [],
    )


def build_payment_plan(option):
    amount = money(option["payment_amount"])
    count = int(float(option["number_of_payments"] or 1))

    first_date = parse_date(
        option["first_payment_date"]
    )

    frequency = int(
        float(option["payment_frequency_days"] or 0)
    )

    if not first_date:
        return []

    schedule = []

    for i in range(count):

        payment_date = (
            first_date
            + timedelta(days=i * frequency)
        )

        schedule.append(
            (
                payment_date,
                amount,
            )
        )

    return schedule


def payment_plan_string(schedule):
    if not schedule:
        return "none"

    return "|".join(
        f"{d.isoformat()}:{format_money(amount)}"
        for d, amount in schedule
    )


# ============================================================
# PAYMENT OPTION SAFETY
# ============================================================

def check_payment_option_safety(
    option,
    forecast,
    minimum_balance,
    desired_completion_date,
    max_installment_months,
):
    """
    Validate the supplied payment option exactly.

    Important:
    Payments outside the 90-day forecast are NOT ignored when
    checking the completion deadline, but safety can only be
    directly verified inside the supplied forecast window.
    """

    schedule = build_payment_plan(option)

    if not schedule:
        return False

    deadline = parse_date(
        desired_completion_date
    )

    if not deadline:
        return False

    # Exact supplied installment option.
    payment_method = (
        option.get("payment_method", "")
        .strip()
        .lower()
    )

    number_of_payments = int(
        float(option.get("number_of_payments") or 1)
    )

    # Respect user's maximum installment months.
    if payment_method == "installments":
        if max_installment_months > 0:

            first_date = schedule[0][0]
            last_date = schedule[-1][0]

            months_used = (
                (last_date.year - first_date.year) * 12
                + (last_date.month - first_date.month)
            )

            if months_used > max_installment_months:
                return False

    # Must finish by requested deadline.
    if schedule[-1][0] > deadline:
        return False

    # Verify every payment that lies in the 90-day window.
    extra_payments = defaultdict(float)

    forecast_start = min(forecast.keys())
    forecast_end = max(forecast.keys())

    for payment_date, amount in schedule:

        if forecast_start <= payment_date <= forecast_end:
            extra_payments[payment_date] += amount

    if not is_safe_forecast(
        forecast,
        minimum_balance,
        dict(extra_payments),
    ):
        return False

    return True


# ============================================================
# USER PAYMENT METHOD PREFERENCES
# ============================================================

def normalize_payment_methods(value):
    raw = split_values(value)

    result = set()

    for item in raw:

        text = (
            item
            .replace("-", "_")
            .replace(" ", "_")
        )

        if "full" in text:
            result.add("full_payment")

        elif "partial" in text:
            result.add("partial_payment")

        elif "install" in text:
            result.add("installments")

        elif "wait" in text:
            result.add("wait")

        elif "not" in text:
            result.add("not_recommended")

    return result


# ============================================================
# FLEXIBLE SPENDING CHANGES
# ============================================================

def find_flexible_recurring_expenses(
    user_events,
    profile,
    home_currency,
    request_date,
):
    """
    Return recurring flexible expenses that are eligible for
    stop/reduce operations.

    Only recurring expenses marked as flexible are considered.
    """

    allowed_reduce = set(
        split_values(
            profile.get(
                "expense_categories_user_willing_to_reduce",
                "",
            )
        )
    )

    allowed_stop = set(
        split_values(
            profile.get(
                "expense_categories_user_willing_to_stop",
                "",
            )
        )
    )

    candidates = []

    recurring = find_recurring_patterns(
        user_events,
        home_currency,
        request_date,
    )

    for pattern in recurring:

        event = pattern["event"]

        flexibility = (
            event.get("flexibility", "")
            .strip()
            .lower()
        )

        category = (
            event.get("category", "")
            .strip()
            .lower()
        )

        event_id = event.get("event_id", "")

        minimum_allowed = money(
            event.get("minimum_allowed_amount")
        )

        if not event_id:
            continue

        if flexibility not in {
            "reducible",
            "stoppable",
            "reducible_or_stoppable",
        }:
            continue

        can_reduce = (
            category in allowed_reduce
            and flexibility in {
                "reducible",
                "reducible_or_stoppable",
            }
        )

        can_stop = (
            category in allowed_stop
            and flexibility in {
                "stoppable",
                "reducible_or_stoppable",
            }
        )

        if not (can_reduce or can_stop):
            continue

        candidates.append({
            "event_id": event_id,
            "category": category,
            "amount": pattern["amount"],
            "minimum_allowed_amount": minimum_allowed,
            "can_reduce": can_reduce,
            "can_stop": can_stop,
            "frequency_days": pattern["frequency_days"],
            "next_date": pattern["next_date"],
        })

    return candidates


def spending_change_candidates(
    user_events,
    profile,
    home_currency,
    request_date,
):
    candidates = find_flexible_recurring_expenses(
        user_events,
        profile,
        home_currency,
        request_date,
    )

    changes = []

    for candidate in candidates:

        if candidate["can_stop"]:
            changes.append({
                "type": "stop",
                "event_id": candidate["event_id"],
                "saving": candidate["amount"],
                "candidate": candidate,
            })

        if candidate["can_reduce"]:
            new_amount = max(
                candidate["minimum_allowed_amount"],
                0.0,
            )

            saving = max(
                0.0,
                candidate["amount"] - new_amount,
            )

            if saving > 0.01:
                changes.append({
                    "type": "reduce",
                    "event_id": candidate["event_id"],
                    "new_amount": new_amount,
                    "saving": saving,
                    "candidate": candidate,
                })

    # Highest savings first.
    changes.sort(
        key=lambda x: (
            -x["saving"],
            x["event_id"],
        )
    )

    return changes


# ============================================================
# BUILD FORECAST WITH SPENDING CHANGES
# ============================================================

def forecast_with_spending_changes(
    base_forecast,
    changes,
    recurring_candidates,
):
    """
    Apply flexible recurring spending reductions/stops to a
    forecast.

    Changes only affect future occurrences of the matching
    recurring event.
    """

    forecast = dict(base_forecast)

    if not changes:
        return forecast

    selected_ids = {
        change["event_id"]
        for change in changes
    }

    adjustment_by_event = {}

    for change in changes:

        event_id = change["event_id"]

        if change["type"] == "stop":
            adjustment_by_event[event_id] = (
                change["saving"]
            )

        elif change["type"] == "reduce":
            adjustment_by_event[event_id] = (
                change["saving"]
            )

    for candidate in recurring_candidates:

        event_id = candidate["event_id"]

        if event_id not in selected_ids:
            continue

        saving = adjustment_by_event.get(
            event_id,
            0.0,
        )

        next_date = candidate["next_date"]

        while next_date in forecast:

            forecast[next_date] += saving

            next_date += timedelta(
                days=candidate["frequency_days"]
            )

    return forecast


def change_string(changes):
    if not changes:
        return "none"

    parts = []

    for change in changes:

        if change["type"] == "stop":
            parts.append(
                f"stop:{change['event_id']}"
            )

        elif change["type"] == "reduce":
            parts.append(
                f"reduce_to:"
                f"{change['event_id']}:"
                f"{format_money(change['new_amount'])}"
            )

    return "|".join(parts[:3])


# ============================================================
# PARTIAL PAYMENT
# ============================================================

def build_partial_plan(
    request_date,
    amount_safe,
    requested_amount,
    earliest_full_date,
):
    if earliest_full_date is None:
        return None

    if amount_safe <= 0:
        return None

    if amount_safe >= requested_amount:
        return None

    remaining = round(
        requested_amount - amount_safe,
        2,
    )

    if remaining <= 0:
        return None

    return (
        f"{request_date.isoformat()}:"
        f"{format_money(amount_safe)}"
        "|"
        f"{earliest_full_date.isoformat()}:"
        f"{format_money(remaining)}"
    )


def partial_plan_is_safe(
    request_date,
    amount_safe,
    requested_amount,
    earliest_full_date,
    forecast,
    minimum_balance,
):
    if earliest_full_date is None:
        return False

    remaining = round(
        requested_amount - amount_safe,
        2,
    )

    payments = defaultdict(float)

    payments[request_date] += amount_safe
    payments[earliest_full_date] += remaining

    return is_safe_forecast(
        forecast,
        minimum_balance,
        dict(payments),
    )


# ============================================================
# PLAN OBJECT
# ============================================================

def make_plan(
    method,
    schedule,
    total_paid,
    first_date,
    payment_count,
    payment_option_id="",
    spending_changes=None,
):
    return {
        "method": method,
        "schedule": schedule,
        "total_paid": total_paid,
        "first_date": first_date,
        "payment_count": payment_count,
        "payment_option_id": payment_option_id,
        "spending_changes": spending_changes or [],
    }


# ============================================================
# PLAN RANKING
# ============================================================

def rank_plan(plan, desired_completion_date):
    deadline = parse_date(desired_completion_date)

    completes_by_deadline = (
        bool(plan.get("schedule"))
        and plan["schedule"][-1][0] <= deadline
    )

    no_changes = (
        len(plan.get("spending_changes", [])) == 0
    )

    first_date = (
        plan.get("first_date")
        or date.max
    )

    option_id = (
        plan.get("payment_option_id")
        or "zzzzzz"
    )

    return (
        0 if completes_by_deadline else 1,
        0 if no_changes else 1,
        round(plan.get("total_paid", 0.0), 2),
        first_date,
        plan.get("payment_count", 999999),
        option_id,
    )


# ============================================================
# DECISION ENGINE
# ============================================================

def decide_request(request):
    request_id = request["request_id"]
    user_id = request["user_id"]

    profile = profiles_by_user.get(user_id)

    if not profile:
        return {
            "request_id": request_id,
            "amount_safe_to_pay": 0,
            "affordability_status": "not_affordable",
            "recommended_payment_method": "not_recommended",
            "payment_plan": "none",
            "earliest_date_for_full_payment": "",
            "spending_changes_needed": "none",
            "decision_explanation": (
                "No financial profile was found for the user."
            ),
        }

    request_date = parse_date(
        request["request_date"]
    )

    desired_completion_date = parse_date(
        request["desired_completion_date"]
    )

    requested_amount = money(
        request["requested_amount"]
    )

    home_currency = (
        profile["home_currency"]
        .strip()
        .upper()
    )

    minimum_balance = money(
        profile["minimum_balance_to_keep"]
    )

    user_methods = normalize_payment_methods(
        profile.get(
            "payment_methods_user_will_consider",
            "",
        )
    )

    allows_partial = bool_value(
        request.get("allows_partial_payment")
    )

    max_installment_months = int(
        float(
            profile.get(
                "max_installment_months",
                0,
            )
            or 0
        )
    )

    user_events = events_by_user.get(
        user_id,
        [],
    )

    # --------------------------------------------------------
    # Forecast
    # --------------------------------------------------------

    forecast, recurring_patterns = build_forecast(
        user_events,
        profile,
        request_date,
        home_currency,
        days=91,
    )

    # --------------------------------------------------------
    # Safe amount today
    # --------------------------------------------------------

    amount_safe_today = calculate_safe_amount(
        forecast,
        requested_amount,
        minimum_balance,
        request_date,
    )

    # The amount that can be committed today is conservative: preserve
    # the minimum balance through the next expected salary/payroll. Future
    # income is used for later affordability, not borrowed against today.
    next_income_dates = []
    for inc in find_recurring_income(user_events, home_currency, request_date):
        if inc["next_date"] > request_date:
            next_income_dates.append(inc["next_date"])
    for d, _ in extract_message_income(user_id, request_date, home_currency):
        if d > request_date:
            next_income_dates.append(d)
    if next_income_dates:
        first_income=min(next_income_dates)
        pre_income={d:b for d,b in forecast.items() if d < first_income}
        if pre_income:
            headroom=min(pre_income.values())-minimum_balance
            amount_safe_today=min(amount_safe_today, max(0.0, round(headroom,2)))
    amount_safe_today=min(requested_amount,max(0.0,amount_safe_today))

    amount_safe_today = min(
        requested_amount,
        max(0.0, amount_safe_today),
    )

    # --------------------------------------------------------
    # Earliest full payment date
    # --------------------------------------------------------

    earliest_full_date = (
        find_earliest_full_payment_date(
            forecast,
            requested_amount,
            minimum_balance,
            request_date,
        )
    )

    # --------------------------------------------------------
    # If full amount is safe today
    # --------------------------------------------------------

    full_payment_allowed = (
        "full_payment" in user_methods
    )

    if (
        amount_safe_today >= requested_amount - 0.01
        and full_payment_allowed
    ):

        schedule = [
            (
                request_date,
                requested_amount,
            )
        ]

        return {
            "request_id": request_id,
            "amount_safe_to_pay": format_money(
                requested_amount
            ),
            "affordability_status": "affordable_now",
            "recommended_payment_method": "full_payment",
            "payment_plan": payment_plan_string(
                schedule
            ),
            "earliest_date_for_full_payment": (
                request_date.isoformat()
            ),
            "spending_changes_needed": "none",
            "decision_explanation": (
                f"The full amount of "
                f"{format_money(requested_amount)} "
                f"{home_currency} can be paid on the "
                f"request date while maintaining the "
                f"required minimum balance."
            ),
        }

    # --------------------------------------------------------
    # Candidate plans
    # --------------------------------------------------------

    candidate_plans = []

    # --------------------------------------------------------
    # Partial payment
    # --------------------------------------------------------

    if (
        allows_partial
        and "partial_payment" in user_methods
        and amount_safe_today > 0.01
        and amount_safe_today < requested_amount - 0.01
        and earliest_full_date is not None
        and earliest_full_date <= desired_completion_date
    ):

        if partial_plan_is_safe(
            request_date,
            amount_safe_today,
            requested_amount,
            earliest_full_date,
            forecast,
            minimum_balance,
        ):

            schedule = [
                (
                    request_date,
                    amount_safe_today,
                ),
                (
                    earliest_full_date,
                    round(
                        requested_amount
                        - amount_safe_today,
                        2,
                    ),
                ),
            ]

            candidate_plans.append(
                make_plan(
                    method="partial_payment",
                    schedule=schedule,
                    total_paid=requested_amount,
                    first_date=request_date,
                    payment_count=2,
                )
            )

    # --------------------------------------------------------
    # Supplied installment options
    # --------------------------------------------------------

    for option in get_request_payment_options(
        request_id
    ):

        method = (
            option.get("payment_method", "")
            .strip()
            .lower()
        )

        if method not in user_methods:
            continue

        if method != "installments":
            continue

        safe = check_payment_option_safety(
            option,
            forecast,
            minimum_balance,
            desired_completion_date,
            max_installment_months,
        )

        if not safe:
            continue

        schedule = build_payment_plan(option)

        if not schedule:
            continue

        total_paid = money(
            option.get("total_payable_amount")
        )

        candidate_plans.append(
            make_plan(
                method="installments",
                schedule=schedule,
                total_paid=total_paid,
                first_date=schedule[0][0],
                payment_count=len(schedule),
                payment_option_id=option.get(
                    "payment_option_id",
                    "",
                ),
            )
        )

    # --------------------------------------------------------
    # Supplied full payment option
    # --------------------------------------------------------

    for option in get_request_payment_options(
        request_id
    ):

        method = (
            option.get("payment_method", "")
            .strip()
            .lower()
        )

        if method != "full_payment":
            continue

        if method not in user_methods:
            continue

        schedule = build_payment_plan(option)

        if not schedule:
            continue

        if schedule[0][0] != request_date:
            continue

        if schedule[-1][0] > desired_completion_date:
            continue

        extra = defaultdict(float)

        for d, amount in schedule:
            if d in forecast:
                extra[d] += amount

        if not is_safe_forecast(
            forecast,
            minimum_balance,
            dict(extra),
        ):
            continue

        candidate_plans.append(
            make_plan(
                method="full_payment",
                schedule=schedule,
                total_paid=money(
                    option.get(
                        "total_payable_amount"
                    )
                ),
                first_date=schedule[0][0],
                payment_count=len(schedule),
                payment_option_id=option.get(
                    "payment_option_id",
                    "",
                ),
            )
        )

    # --------------------------------------------------------
    # Flexible spending changes
    # --------------------------------------------------------

    flexible_candidates = spending_change_candidates(
        user_events,
        profile,
        home_currency,
        request_date,
    )

    # Try combinations of up to 3 changes.
    # Deterministic and small enough for this dataset.
    combinations = [[]]

    for candidate in flexible_candidates[:8]:

        new_combinations = []

        for existing in combinations:

            if len(existing) >= 3:
                continue

            # Do not reference same event twice.
            if any(
                x["event_id"] == candidate["event_id"]
                for x in existing
            ):
                continue

            new_combinations.append(
                existing + [candidate]
            )

        combinations.extend(
            new_combinations
        )

    # Remove oversized combination set.
    combinations = combinations[:200]

    recurring_candidates = find_flexible_recurring_expenses(
        user_events,
        profile,
        home_currency,
        request_date,
    )

    for changes in combinations:

        if not changes:
            continue

        changed_forecast = forecast_with_spending_changes(
            forecast,
            changes,
            recurring_candidates,
        )

        changed_safe_amount = calculate_safe_amount(
            changed_forecast,
            requested_amount,
            minimum_balance,
            request_date,
        )

        changed_earliest = (
            find_earliest_full_payment_date(
                changed_forecast,
                requested_amount,
                minimum_balance,
                request_date,
            )
        )

        if changed_earliest is None:
            continue

        # Partial with spending changes
        if (
            allows_partial
            and "partial_payment" in user_methods
            and changed_safe_amount > 0.01
            and changed_safe_amount < requested_amount - 0.01
            and changed_earliest <= desired_completion_date
        ):

            if partial_plan_is_safe(
                request_date,
                changed_safe_amount,
                requested_amount,
                changed_earliest,
                changed_forecast,
                minimum_balance,
            ):

                schedule = [
                    (
                        request_date,
                        changed_safe_amount,
                    ),
                    (
                        changed_earliest,
                        round(
                            requested_amount
                            - changed_safe_amount,
                            2,
                        ),
                    ),
                ]

                candidate_plans.append(
                    make_plan(
                        method="partial_payment",
                        schedule=schedule,
                        total_paid=requested_amount,
                        first_date=request_date,
                        payment_count=2,
                        spending_changes=changes,
                    )
                )

        # Full payment with changes
        if (
            "full_payment" in user_methods
            and changed_safe_amount >= requested_amount - 0.01
        ):

            schedule = [
                (
                    request_date,
                    requested_amount,
                )
            ]

            candidate_plans.append(
                make_plan(
                    method="full_payment",
                    schedule=schedule,
                    total_paid=requested_amount,
                    first_date=request_date,
                    payment_count=1,
                    spending_changes=changes,
                )
            )

        # Wait after spending changes
        if (
            "wait" in user_methods
            and changed_earliest is not None
            and changed_earliest <= desired_completion_date
        ):

            schedule = [
                (
                    changed_earliest,
                    requested_amount,
                )
            ]

            candidate_plans.append(
                make_plan(
                    method="wait",
                    schedule=schedule,
                    total_paid=requested_amount,
                    first_date=changed_earliest,
                    payment_count=1,
                    spending_changes=changes,
                )
            )

    # --------------------------------------------------------
    # Rank candidate plans
    # --------------------------------------------------------

    if candidate_plans:

        candidate_plans.sort(
            key=lambda p: rank_plan(
                p,
                desired_completion_date,
            )
        )

        selected = candidate_plans[0]

        method = selected["method"]

        if method == "full_payment":
            status = "affordable_now"

        else:
            status = "affordable_with_plan"

        selected_plan = payment_plan_string(
            selected["schedule"]
        )

        change_text = change_string(
            selected["spending_changes"]
        )

        return {
            "request_id": request_id,
            "amount_safe_to_pay": format_money(
                amount_safe_today
            ),
            "affordability_status": status,
            "recommended_payment_method": method,
            "payment_plan": selected_plan,
            "earliest_date_for_full_payment": (
                earliest_full_date.isoformat()
                if earliest_full_date
                else ""
            ),
            "spending_changes_needed": change_text,
            "decision_explanation": (
                f"The selected {method} plan safely "
                f"completes the requested "
                f"{format_money(requested_amount)} "
                f"{home_currency} by the requested deadline "
                f"while maintaining the required minimum "
                f"balance."
            ),
        }

    # --------------------------------------------------------
    # WAIT
    # --------------------------------------------------------

    if (
        "wait" in user_methods
        and earliest_full_date is not None
        and earliest_full_date <= desired_completion_date
    ):

        schedule = [
            (
                earliest_full_date,
                requested_amount,
            )
        ]

        return {
            "request_id": request_id,
            "amount_safe_to_pay": format_money(
                amount_safe_today
            ),
            "affordability_status": "affordable_later",
            "recommended_payment_method": "wait",
            "payment_plan": payment_plan_string(
                schedule
            ),
            "earliest_date_for_full_payment": (
                earliest_full_date.isoformat()
            ),
            "spending_changes_needed": "none",
            "decision_explanation": (
                f"The full amount is not safely payable "
                f"on the request date, but the forecast "
                f"indicates it becomes safe on "
                f"{earliest_full_date.isoformat()}."
            ),
        }

    # --------------------------------------------------------
    # Not affordable
    # --------------------------------------------------------

    return {
        "request_id": request_id,
        "amount_safe_to_pay": format_money(
            amount_safe_today
        ),
        "affordability_status": "not_affordable",
        "recommended_payment_method": "not_recommended",
        "payment_plan": "none",
        "earliest_date_for_full_payment": (
            earliest_full_date.isoformat()
            if earliest_full_date
            else ""
        ),
        "spending_changes_needed": "none",
        "decision_explanation": (
            "No currently available payment approach "
            "can safely complete the request within the "
            "required constraints while maintaining the "
            "user's minimum balance."
        ),
    }


# ============================================================
# VALIDATE OUTPUT ROW
# ============================================================

ALLOWED_STATUS = {
    "affordable_now",
    "affordable_with_plan",
    "affordable_later",
    "not_affordable",
}

ALLOWED_METHODS = {
    "full_payment",
    "partial_payment",
    "installments",
    "wait",
    "not_recommended",
}


def validate_output_row(row, request):
    errors = []

    requested_amount = money(
        request["requested_amount"]
    )

    safe_amount = money(
        row["amount_safe_to_pay"]
    )

    if safe_amount < -0.01:
        errors.append("negative amount_safe_to_pay")

    if safe_amount > requested_amount + 0.01:
        errors.append(
            "amount_safe_to_pay exceeds requested_amount"
        )

    if row["affordability_status"] not in ALLOWED_STATUS:
        errors.append(
            "invalid affordability_status"
        )

    if row["recommended_payment_method"] not in ALLOWED_METHODS:
        errors.append(
            "invalid recommended_payment_method"
        )

    if (
        row["affordability_status"]
        == "affordable_now"
    ):
        if row["earliest_date_for_full_payment"] != request[
            "request_date"
        ]:
            errors.append(
                "affordable_now earliest date "
                "must equal request_date"
            )

    if (
        row["recommended_payment_method"]
        == "partial_payment"
    ):
        if (
            row["affordability_status"]
            != "affordable_with_plan"
        ):
            errors.append(
                "partial payment must be "
                "affordable_with_plan"
            )

        if not bool_value(
            request.get("allows_partial_payment")
        ):
            errors.append(
                "partial payment not allowed"
            )

    # Spending changes maximum 3.
    changes = row["spending_changes_needed"]

    if changes and changes != "none":

        if len(changes.split("|")) > 3:
            errors.append(
                "more than 3 spending changes"
            )

    return errors


# ============================================================
# RUN ALL REQUESTS
# ============================================================

print()
print("=" * 60)
print("RUNNING FULL DATASET")
print("=" * 60)

results = []

request_lookup = {
    r["request_id"]: r
    for r in requests
}

error_count = 0

for index, request in enumerate(
    requests,
    start=1,
):

    request_id = request["request_id"]

    try:

        result = decide_request(
            request
        )

        validation_errors = validate_output_row(
            result,
            request,
        )

        if validation_errors:

            error_count += 1

            print(
                f"ERROR: {request_id}: "
                + "; ".join(validation_errors)
            )

        results.append(result)

        if index % 25 == 0:
            print(
                f"Processed {index}/{len(requests)}"
            )

    except Exception as exc:

        error_count += 1

        print(
            f"ERROR: {request_id}: {exc}"
        )

        results.append({
            "request_id": request_id,
            "amount_safe_to_pay": "0",
            "affordability_status": "not_affordable",
            "recommended_payment_method": "not_recommended",
            "payment_plan": "none",
            "earliest_date_for_full_payment": "",
            "spending_changes_needed": "none",
            "decision_explanation": (
                "Unable to produce a safe financial "
                "recommendation for this request."
            ),
        })


# ============================================================
# WRITE OUTPUT
# ============================================================

with open(
    OUTPUT_FILE,
    "w",
    encoding="utf-8",
    newline="",
) as f:

    writer = csv.DictWriter(
        f,
        fieldnames=OUTPUT_COLUMNS,
    )

    writer.writeheader()

    for result in results:

        writer.writerow({
            column: result.get(column, "")
            for column in OUTPUT_COLUMNS
        })


# ============================================================
# FINAL CHECK
# ============================================================

print()
print("=" * 60)
print("FINAL CHECK")
print("=" * 60)

print(
    f"Rows created: {len(results)}"
)

print(
    f"Errors: {error_count}"
)

print(
    f"Output: {OUTPUT_FILE}"
)

print()
print("Columns:")

for column in OUTPUT_COLUMNS:
    print(f"  {column}")

print()

if len(results) == len(requests):
    print("SUCCESS: one output row exists for every request.")
else:
    print(
        "WARNING: output row count does not match "
        "request count."
    )

if error_count == 0:
    print("SUCCESS: no validation errors detected.")
else:
    print(
        f"WARNING: {error_count} validation errors detected."
    )

print()
print("Done.")