# HackerRank Orchestrate — Buy or Wait

Deterministic Python solution for the financial affordability challenge.

## Run

From the repository root:

```bash
python code/main.py
```

This reads the supplied files from `dataset/` and writes `output.csv` in the repository root.

## Main features

- Reconstructs the user's current financial position.
- Handles pending/scheduled future debits and credits.
- Detects recurring expense patterns from settled history.
- Detects recurring salary patterns.
- Uses relevant payroll messages as financial evidence.
- Attempts to resolve blank event amounts from linked images when local Tesseract OCR is available; unresolved amounts are never treated as zero.
- Supports payment-option validation, partial payment, installments, waiting, and flexible spending changes.
- Keeps output deterministic and validates the required output schema.

## Submission contents

Do not include `dataset/`, `.venv/`, `__pycache__/`, or other build artifacts in `code.zip`.
